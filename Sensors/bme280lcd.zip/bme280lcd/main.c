
#ifndef F_CPU
#define F_CPU 16000000UL // set the CPU clock
#endif
#include <string.h>       // Standard C Library for string functions
#include <stdint.h>       // Standard C Library for uint8_t, uint16_t, uint32_t, etc
#include <stdio.h>        // Standard C Library for sprintf() function
#include <avr/io.h>       // Standard AVR IO Library
#include <util/delay.h>   // Standard AVR Delay Library
#include <stdlib.h>       // Standard C Library for itoa() function
#include "bme280.c"       // BME280 Library
#include <avr/io.h>       // Standard AVR IO Library
#include <util/delay.h>   // Standard AVR Delay Library
#include "lcd.c"          // LCD Library
char output[20];          // output string
int result = 0;           // result
uint16_t temperature = 0; // temperature
float humidity = 0;       // humidity
char str_val[20];         // string value
uint16_t pressure = 0;    // pressure
int main(void)
{

    LCD_Init();                                           /* Initialize LCD */
    LCD_Clear();                                          /* Clear LCD */
    LCD_gotoxy(0, 0);                                     /* Enter column and row position */
    LCD_string("BME280");                                 // print BME280
    _delay_ms(500);                                       // wait 500ms
    LCD_Clear();                                          // Clear LCD
    DDRC = 0Xff;                                          // set the port as OUTPUT
    Bme280CalibrationData calibrationData;                // calibration data
    result = bme280ReadCalibrationData(&calibrationData); // read calibration data
    while (1)
    {
        if (result == BME280_OK) // if read calibration data is OK
        {
            Bme280Data data;
            result = bme280ReadData(BME280_OSS_1, BME280_OSS_1, BME280_OSS_1, &data, &calibrationData); // read data

            if (result == BME280_OK) // if read data is OK
            {
                temperature = data.temperatureC;       // get temperature
                humidity = data.humidityPercent;       // get humidity
                pressure = data.pressurePa;            // get pressure
                pressure = pressure / 100;             // convert pressure to mmHg
                sprintf(output, "T:%d", temperature);  // print temperature and humidity
                LCD_gotoxy(0, 0);                      // Enter column and row position
                LCD_string(output);                    // print temperature and humidity
                LCD_WriteData(0xDF);                   // print degree symbol
                LCD_string("C ");                      // print C
                sprintf(output, "P:%dmmHg", pressure); // print pressure
                LCD_string(output);                    // print pressure
                LCD_gotoxy(0, 1);                      // Enter column and row position
                LCD_string("H:");                      // print humidity
                dtostrf(humidity, 3, 2, str_val);      // convert humidity to string
                strcat(str_val, "%");                  // add % to string
                LCD_string(str_val);                   // print humidity
                _delay_ms(100);                        // wait 100ms
            }
        }
    }
    return 0; // never reached
}
