#define F_CPU 16000000UL
#include <avr/io.h>		//Defines pins, ports, etc.
#include <util/delay.h> //Defines delay functions
#include <stdio.h>		//Defines sprintf function
#include <util/delay.h> //Defines delay functions
#include <stdlib.h>		//Defines dtostrf function
#include <string.h>		//Defines strcat function
#include "lcd.c"		//Include LCD header file
static inline void initADC0(void)
{
	ADMUX |= (1 << REFS0);				   // reference voltage on AVCC
	ADCSRA |= (1 << ADPS1) | (1 << ADPS0); // ADC clock prescaler /8
	ADCSRA |= (1 << ADEN);				   // enables the ADC
}

int main(void)
{
	float value; // variable to store ADC value

	char data[20];
	LCD_Init();	 /* Initialize LCD */
	LCD_Clear(); /* Clear LCD */

	initADC0(); // initialize the ADC

	while (1)
	{
		LCD_gotoxy(0, 0);					   /* Enter column and row position */
		LCD_string("Moisture = ");			   // display string on LCD
		ADCSRA |= (1 << ADSC);				   // start ADC conversion
		loop_until_bit_is_clear(ADCSRA, ADSC); // wait until ADC conversion is done
		value = ADC;						   // read ADC in
		value = (value * 100) / 1023;		   // convert ADC value to percent
		dtostrf(value, 3, 2, data);			   // convert float to string
		strcat(data, "%   ");				   /* Concatenate unit of % */
		LCD_gotoxy(11, 0);					   // enter column and row position
		LCD_string(data);					   // display data on LCD
		_delay_ms(500);						   // wait a bit
		LCD_Clear();						   // clear LCD
	}
	return 0;
}
