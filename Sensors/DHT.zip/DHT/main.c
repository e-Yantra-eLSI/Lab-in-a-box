

#ifndef F_CPU
#define F_CPU 16000000UL // set the CPU clock

#endif
#include <avr/io.h>									 // Standard AVR IO Library
#include <util/delay.h>								 // Standard AVR Delay Library
#include <stdlib.h>									 // Standard C Library for itoa() function
#include <stdio.h>									 // Standard C Library for sprintf() function
#include "lcd.c"									 // LCD Library
#define DHT11_PIN 5									 // define DHT11 pin
uint8_t c = 0, I_RH, D_RH, I_Temp, D_Temp, CheckSum; // variables for DHT11

void Request() /* Microcontroller send start pulse/request */
{
	DDRG |= (1 << DHT11_PIN);	// set as output port
	PORTG &= ~(1 << DHT11_PIN); /* set to low pin */
	_delay_ms(20);				/* wait for 20ms */
	PORTG |= (1 << DHT11_PIN);	/* set to high pin */
}

void Response() /* receive response from DHT11 */
{
	DDRG &= ~(1 << DHT11_PIN);		// set as input port
	while (PING & (1 << DHT11_PIN)) // wait until pin goes low
		;
	while ((PING & (1 << DHT11_PIN)) == 0) // wait until pin goes high
		;
	while (PING & (1 << DHT11_PIN)) // wait until pin goes low
		;
}

uint8_t Receive_data() /* receive data */
{
	int q; // for looping 8 times
	for (q = 0; q < 8; q++)
	{
		while ((PING & (1 << DHT11_PIN)) == 0) /* check received bit 0 or 1 */
			;
		_delay_us(30);					// if high pulse is greater than 30ms
		if (PING & (1 << DHT11_PIN))	/* if high pulse is greater than 30ms */
			c = (c << 1) | (0x01);		/* then its logic HIGH */
		else							/* otherwise its logic LOW */
			c = (c << 1);				// shift left
		while (PING & (1 << DHT11_PIN)) // wait until pin goes low
			;
	}
	return c;
}

int main(void)
{
	char data[5];				   // store data
	LCD_Init();					   /* Initialize LCD */
	LCD_Clear();				   /* Clear LCD */
	LCD_Line_Column(0, 0);		   /* Enter column and row position */
	LCD_WriteString("Humidity ="); // Display string on LCD
	LCD_gotoxy(0, 1);			   // Enter column and row position
	LCD_WriteString("Temp = ");	   // Display string on LCD

	while (1)
	{
		Request();				   /* send start pulse */
		Response();				   /* receive response */
		I_RH = Receive_data();	   /* store first eight bit in I_RH */
		D_RH = Receive_data();	   /* store next eight bit in D_RH */
		I_Temp = Receive_data();   /* store next eight bit in I_Temp */
		D_Temp = Receive_data();   /* store next eight bit in D_Temp */
		CheckSum = Receive_data(); /* store next eight bit in CheckSum */

		if ((I_RH + D_RH + I_Temp + D_Temp) != CheckSum)
		{
			LCD_gotoxy(0, 0);		  // Enter column and row position
			LCD_WriteString("Error"); // Display string on LCD
		}

		else
		{
			itoa(I_RH, data, 10); // convert I_RH to character
			LCD_gotoxy(10, 0);	  // Enter column and row position
			LCD_string(data);	  // Display string on LCD
			LCD_string(".");	  //

			itoa(D_RH, data, 10); // convert D_RH to character
			LCD_string(data);	  // Display string on LCD
			LCD_string("%");	  // Display string on LCD

			itoa(I_Temp, data, 10); // convert I_Temp to character
			LCD_gotoxy(6, 1);		// Enter column and row position
			LCD_string(data);		// Display string on LCD
			LCD_string(".");		// Display string on LCD

			itoa(D_Temp, data, 10); // convert D_Temp to character
			LCD_string(data);		// Display string on LCD
			LCD_WriteData(0xDF);	// Display degree symbol on LCD
			LCD_string("C ");		// Display string on LCD

			itoa(CheckSum, data, 10); // convert CheckSum to character
			LCD_string(data);		  // Display string on LCD
			LCD_string(" ");		  // Display string on LCD
		}

		_delay_ms(10); // wait for 10ms
	}
}
