#define F_CPU 16000000UL
#include <avr/io.h>		//Defines pins, ports, etc.
#include <util/delay.h> //Defines delay functions
#include <stdio.h>		//Defines sprintf function
#include <util/delay.h> //Defines delay functions
#include <stdlib.h>		//Defines dtostrf function
#include <string.h>		//Defines strcat function
#include "uart.c"		//uart header file
float value;			// variable to store ADC value
char data[20];			// buffer for uart output
int i = 0;

static inline void initADC0(void)
{
	ADMUX |= (1 << REFS0);				   // reference voltage on AVCC
	ADCSRA |= (1 << ADPS1) | (1 << ADPS0); // ADC clock prescaler /8
	ADCSRA |= (1 << ADEN);				   // enables the ADC
}
int main(void)
{
	DDRA = DDRA & (~1 << 0); // Makes of PORTA0 as Input

	DDRA = DDRA & (~1 << 1); // Makes of PORTE1 as Input

	initADC0();	  // initialize the ADC
	uart_start(); // initialize the UART

	while (1)
	{
		if ((PINA & (1 << 0) == 1) || (PINA & (1 << 1) == 1))
		{
			uart_sendstr("!");
		}
		else
		{
			ADCSRA |= (1 << ADSC);				   // start ADC conversion
			loop_until_bit_is_clear(ADCSRA, ADSC); // wait until ADC conversion is done
			value = ADC;
			dtostrf(value, 3, 2, data); // convert float to string
			uart_sendstr(data);
		}
	}
	return 0;
}