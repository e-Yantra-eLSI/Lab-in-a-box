
/**************************** PreProcessors ******************************/
#define F_CPU 16000000UL // set the CPU clock
#include <avr/io.h>      // Standard AVR IO Library
#include <util/delay.h>  // Standard AVR Delay Library
#include "lcd.c"         // LCD Library
/************************ Functions **************************/

int main(void)
{
    LCD_Init();                 // LCD initialization in 4-bits mode
    LCD_gotoxy(0, 0);           // go to first line and first column
    LCD_string("Origami With"); // send this string
    _delay_ms(1000);            // delay 1s
    LCD_gotoxy(0, 1);           // go to second line and first column
    _delay_ms(1000);            // delay 1s
    LCD_string("Electronics");  // send this string
    while (1)
    {
    }
}
