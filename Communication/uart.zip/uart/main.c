#define F_CPU 16000000UL
#include <avr/io.h>     //Defines pins, ports, etc.
#include <util/delay.h> //Defines delay functions
#include <stdio.h>      //Defines sprintf function
#include <util/delay.h> //Defines delay functions
#include <stdlib.h>     //Defines dtostrf function
#include <string.h>     //Defines strcat function
#include "uart.c"       //uart header file
int main(void)
{

    uart_start(); // initialize the UART

    while (1)
    {
        uart_sendstr("Hello World");
    }
    return 0;
}